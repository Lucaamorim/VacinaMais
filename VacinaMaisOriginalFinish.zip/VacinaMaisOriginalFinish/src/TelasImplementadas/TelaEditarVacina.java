
package TelasImplementadas;

import java.awt.Cursor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author lucas
 */
public class TelaEditarVacina extends javax.swing.JFrame {

    /**
     * Creates new form TelaEditarVacina
     */
    public TelaEditarVacina() {
        initComponents();
        setExtendedState(TelaEditarVacina.MAXIMIZED_BOTH);
        
    }
    
   
    
 public void MetodoTable(String sql) {
         try {
            Connection con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3355/db_vacinamais", "root", "usbw");
            PreparedStatement banco = (PreparedStatement)con.prepareStatement(sql);
            banco.execute(); // cria o vetor
            
            ResultSet resultado = banco.executeQuery(sql);
            
            DefaultTableModel model =(DefaultTableModel) TabelaVacina.getModel();
            model.setNumRows(0);
            
             
            while(resultado.next())
            {
                model.addRow(new Object[]
                {
                    //retorna os dados da tabela do BD, cada campo e um coluna.
                    resultado.getString("id_vacina"),
                    resultado.getString("nome_vacina"),
                    resultado.getString("descricao_vacina"),
                    resultado.getString("estrategia_vacina"),
                    resultado.getString("estoque_vacina"),
                    resultado.getString("nome_lote_vacina"),
                    resultado.getString("data_validade_vacina"),
                     
                    });
            }
            banco.close();
            con.close();
        } catch (SQLException ex) {
            System.out.println("o erro foi " +ex);
        }
     }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        vacinamais1 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        nomevacinatxt = new javax.swing.JTextField();
        validadevacinatxt = new javax.swing.JTextField();
        estrategiacbx = new javax.swing.JComboBox<>();
        cadastrarLote = new javax.swing.JButton();
        descricaovactxt = new javax.swing.JTextField();
        qntestoquetxt = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        AtualizarVacina = new javax.swing.JButton();
        deletarVacina = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        idtxt = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        TabelaVacina = new javax.swing.JTable();
        painelmenu = new javax.swing.JPanel();
        Cadastrese = new javax.swing.JButton();
        FaleConosco = new javax.swing.JButton();
        loteselect = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 153, 204));

        jPanel7.setBackground(new java.awt.Color(0, 204, 255));

        vacinamais1.setFont(new java.awt.Font("Bauhaus 93", 0, 85)); // NOI18N
        vacinamais1.setForeground(new java.awt.Color(255, 255, 255));
        vacinamais1.setText("Vacina +");
        vacinamais1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                vacinamais1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                vacinamais1MouseEntered(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(vacinamais1)
                .addContainerGap(1051, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addGap(0, 27, Short.MAX_VALUE)
                .addComponent(vacinamais1, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                jPanel4ComponentResized(evt);
            }
        });

        jButton6.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jButton6.setText("| Cadastrar");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jButton7.setText("| Gerenciar");
        jButton7.setEnabled(false);
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton7, javax.swing.GroupLayout.DEFAULT_SIZE, 246, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(216, Short.MAX_VALUE))
        );

        jLabel2.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 153, 102));
        jLabel2.setText("Gerenciar Vacinas");

        jLabel3.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel3.setText("Nome Vacina:");

        jLabel5.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel5.setText("Descrição:");

        jLabel6.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel6.setText("Quantidade Estoque:");

        jLabel7.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel7.setText("Estratégia:");

        jLabel10.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel10.setText("Lote/Fabricante:");

        jLabel12.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel12.setText("Data de Validade:");

        estrategiacbx.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecionar Item...", "COVID-19", "Gripe", "Sarampo", "Tétano", "Hepatite A", "Hepatite B", "Penta ", "Pneumocócica 10 valente", "Inativada Poliomielite (VIP)", "Oral Poliomielite (VOP)", "Rotavírus Humano (VRH)", "Meningocócica C (conjugada)", "Febre amarela", "Tríplice viral", "Tetraviral", "DTP (tríplice bacteriana)", "Varicela", "HPV quadrivalente", "dT (dupla adulto)", "dTpa (DTP adulto)", "Menigocócica ACWY", "Raiva" }));

        cadastrarLote.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        cadastrarLote.setForeground(new java.awt.Color(0, 153, 255));
        cadastrarLote.setText("Cadastrar Lote >>");
        cadastrarLote.setContentAreaFilled(false);
        cadastrarLote.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                cadastrarLoteMouseEntered(evt);
            }
        });
        cadastrarLote.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadastrarLoteActionPerformed(evt);
            }
        });

        descricaovactxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                descricaovactxtActionPerformed(evt);
            }
        });

        jPanel6.setBackground(new java.awt.Color(153, 153, 255));
        jPanel6.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        AtualizarVacina.setBackground(new java.awt.Color(0, 153, 204));
        AtualizarVacina.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        AtualizarVacina.setForeground(new java.awt.Color(255, 255, 255));
        AtualizarVacina.setText("Atualizar");
        AtualizarVacina.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AtualizarVacinaActionPerformed(evt);
            }
        });

        deletarVacina.setBackground(new java.awt.Color(0, 153, 204));
        deletarVacina.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        deletarVacina.setForeground(new java.awt.Color(255, 255, 255));
        deletarVacina.setText("Excluir");
        deletarVacina.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletarVacinaActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel1.setText("ID:");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(AtualizarVacina, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 46, Short.MAX_VALUE)
                .addComponent(deletarVacina, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(idtxt, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(idtxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AtualizarVacina)
                    .addComponent(deletarVacina))
                .addGap(15, 15, 15))
        );

        TabelaVacina.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nome", "Descricao", "Estategia", "Quantidade no Estoque", "Nome Fabricante", "Data de Vencimento"
            }
        ));
        TabelaVacina.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabelaVacinaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TabelaVacina);

        painelmenu.setBackground(new java.awt.Color(0, 153, 204));
        painelmenu.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        painelmenu.setRequestFocusEnabled(false);

        Cadastrese.setBackground(new java.awt.Color(0, 153, 153));
        Cadastrese.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        Cadastrese.setForeground(new java.awt.Color(255, 255, 255));
        Cadastrese.setText("Cadastre");
        Cadastrese.setBorder(null);
        Cadastrese.setContentAreaFilled(false);
        Cadastrese.setDefaultCapable(false);
        Cadastrese.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                CadastreseMouseEntered(evt);
            }
        });
        Cadastrese.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CadastreseActionPerformed(evt);
            }
        });

        FaleConosco.setBackground(new java.awt.Color(0, 153, 153));
        FaleConosco.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        FaleConosco.setForeground(new java.awt.Color(255, 255, 255));
        FaleConosco.setText("Fale Conosco");
        FaleConosco.setContentAreaFilled(false);
        FaleConosco.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                FaleConoscoMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                FaleConoscoMouseEntered(evt);
            }
        });
        FaleConosco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FaleConoscoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout painelmenuLayout = new javax.swing.GroupLayout(painelmenu);
        painelmenu.setLayout(painelmenuLayout);
        painelmenuLayout.setHorizontalGroup(
            painelmenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelmenuLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Cadastrese, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(FaleConosco))
        );
        painelmenuLayout.setVerticalGroup(
            painelmenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, painelmenuLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(painelmenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Cadastrese)
                    .addComponent(FaleConosco)))
        );

        loteselect.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecionar item...", "Butamtam", "Johnssons" }));
        loteselect.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                loteselectAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addComponent(jLabel10)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(loteselect, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cadastrarLote))
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addComponent(jLabel12)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(validadevacinatxt, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addContainerGap(752, Short.MAX_VALUE))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jLabel6)
                                                .addComponent(jLabel7))
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(qntestoquetxt, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel2)
                                            .addGroup(jPanel4Layout.createSequentialGroup()
                                                .addComponent(jLabel3)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                    .addComponent(estrategiacbx, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(nomevacinatxt, javax.swing.GroupLayout.DEFAULT_SIZE, 271, Short.MAX_VALUE)
                                                    .addComponent(descricaovactxt))))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(320, 320, 320))))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1)
                            .addComponent(painelmenu, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap())))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(painelmenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(14, 14, 14)
                                .addComponent(jLabel2)
                                .addGap(18, 18, 18)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel3)
                                    .addComponent(nomevacinatxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel5)
                                    .addComponent(descricaovactxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(estrategiacbx, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(qntestoquetxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(cadastrarLote, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(loteselect, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(validadevacinatxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(26, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void AtualizarVacinaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AtualizarVacinaActionPerformed
        try {
            Connection conexao = null;
            PreparedStatement statement = null;

            String url = "jdbc:mysql://localhost:3355/db_vacinamais";
            String usuario = "root";
            String senha = "usbw";

            conexao = DriverManager.getConnection(url, usuario, senha);

            String sql = "update vacina set nome_vacina = ?,descricao_vacina = ?,estrategia_vacina = ?,estoque_vacina = ?,nome_lote_vacina = ?,\n" +
            "data_validade_vacina = ? where id_vacina = ?;";
            statement = conexao.prepareStatement(sql);

            statement.setString(1, nomevacinatxt.getText());
            statement.setString(2, descricaovactxt.getText());
            statement.setString(3, estrategiacbx.getSelectedItem().toString());
            statement.setString(4, qntestoquetxt.getText());
            statement.setString(5, loteselect.getSelectedItem().toString());
            statement.setString(6, validadevacinatxt.getText());
            statement.setString(7, idtxt.getText());

            int linhasAfetadas = statement.executeUpdate();

            if(linhasAfetadas > 0 ){
                JOptionPane.showMessageDialog(rootPane, "Vacina Atualizada");
            this.MetodoTable("SELECT * FROM vacina");
            }else {
                JOptionPane.showMessageDialog(null, "Erro ao inserir");
            }

            statement.close();
        } catch (SQLException ex) {
            Logger.getLogger(TelaEditarPaciente.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_AtualizarVacinaActionPerformed

    private void cadastrarLoteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadastrarLoteActionPerformed
        TelaEditarLote lote = new TelaEditarLote();
        lote.setVisible(true);
    }//GEN-LAST:event_cadastrarLoteActionPerformed

    private void descricaovactxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_descricaovactxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_descricaovactxtActionPerformed

    private void deletarVacinaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletarVacinaActionPerformed
       
        Connection conexao = null;
        PreparedStatement statement = null;
        
        String url = "jdbc:mysql://localhost:3355/db_vacinamais";
        String usuario = "root";
        String senha = "usbw";
        
        try {
            conexao = DriverManager.getConnection(url, usuario, senha);
            String sql = "delete from vacina where id_vacina = ?";
            
            statement = conexao.prepareStatement(sql);
            statement.setString(1, idtxt.getText());
            
            int linhasAfetadas = statement.executeUpdate();
            
            if(linhasAfetadas > 0){
                JOptionPane.showMessageDialog(rootPane,"Dados excluidos com sucesso");
                this.MetodoTable("SELECT * FROM vacina");
            }else {
                JOptionPane.showMessageDialog(rootPane,"Erro ao deletar dados");
            }
            
            // TODO add your handling code here:
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane,"Erro ao inserir dados: " + ex.getMessage());
        } finally {
            try{
                if(statement != null){
                    statement.close();
                }  
                if(statement != null){
                    conexao.close();
                }
            }   catch (SQLException ex) {
                JOptionPane.showMessageDialog(rootPane,"Erro ao fechar conexão " + ex.getMessage());
            }
        }
        
        
    }//GEN-LAST:event_deletarVacinaActionPerformed

    private void TabelaVacinaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabelaVacinaMouseClicked
        int linha = TabelaVacina.getSelectedRow();
        
        idtxt.setText(TabelaVacina.getValueAt(linha,0).toString());
        nomevacinatxt.setText(TabelaVacina.getValueAt(linha,1).toString());   
        descricaovactxt.setText(TabelaVacina.getValueAt(linha,2).toString()); 
        estrategiacbx.setSelectedItem(TabelaVacina.getValueAt(linha,3).toString());
        qntestoquetxt.setText(TabelaVacina.getValueAt(linha,4).toString());   
        loteselect.setSelectedItem(TabelaVacina.getValueAt(linha,5).toString());
        validadevacinatxt.setText(TabelaVacina.getValueAt(linha,6).toString());
        
    }//GEN-LAST:event_TabelaVacinaMouseClicked

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        TelaCadastroVacina cadastrar = new TelaCadastroVacina();
        cadastrar.setVisible(true);
        dispose();       
    }//GEN-LAST:event_jButton6ActionPerformed

    private void CadastreseMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CadastreseMouseEntered
        Cadastrese.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_CadastreseMouseEntered

    private void CadastreseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CadastreseActionPerformed

        TelaEscolhaCadastro escolhe = new TelaEscolhaCadastro();
        escolhe.setVisible(true);
        dispose();

    }//GEN-LAST:event_CadastreseActionPerformed

    private void FaleConoscoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FaleConoscoMouseClicked

    }//GEN-LAST:event_FaleConoscoMouseClicked

    private void FaleConoscoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FaleConoscoMouseEntered
        FaleConosco.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_FaleConoscoMouseEntered

    private void jPanel4ComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_jPanel4ComponentResized
         this.MetodoTable("SELECT * FROM vacina");
    }//GEN-LAST:event_jPanel4ComponentResized

    private void cadastrarLoteMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cadastrarLoteMouseEntered
        cadastrarLote.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_cadastrarLoteMouseEntered

    private void loteselectAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_loteselectAncestorAdded

        this.MetodoTable("select * from lote_fabricante");
    }//GEN-LAST:event_loteselectAncestorAdded

    private void FaleConoscoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FaleConoscoActionPerformed
        TelaAjudaBotao ajuda = new TelaAjudaBotao();
        ajuda.setVisible(true);
    }//GEN-LAST:event_FaleConoscoActionPerformed

    private void vacinamais1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_vacinamais1MouseClicked
        ATelaInicialVacinamais tela = new ATelaInicialVacinamais();
        tela.setVisible(true);
        dispose();
    }//GEN-LAST:event_vacinamais1MouseClicked

    private void vacinamais1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_vacinamais1MouseEntered

        vacinamais1.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_vacinamais1MouseEntered

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton7ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaEditarVacina.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaEditarVacina.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaEditarVacina.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaEditarVacina.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaEditarVacina().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AtualizarVacina;
    private javax.swing.JButton Cadastrese;
    private javax.swing.JButton FaleConosco;
    private javax.swing.JTable TabelaVacina;
    private javax.swing.JButton cadastrarLote;
    private javax.swing.JButton deletarVacina;
    private javax.swing.JTextField descricaovactxt;
    private javax.swing.JComboBox<String> estrategiacbx;
    private javax.swing.JTextField idtxt;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox<String> loteselect;
    private javax.swing.JTextField nomevacinatxt;
    private javax.swing.JPanel painelmenu;
    private javax.swing.JTextField qntestoquetxt;
    private javax.swing.JLabel vacinamais1;
    private javax.swing.JTextField validadevacinatxt;
    // End of variables declaration//GEN-END:variables
}
