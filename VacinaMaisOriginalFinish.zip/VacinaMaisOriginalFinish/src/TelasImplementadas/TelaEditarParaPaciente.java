/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package TelasImplementadas;

import java.awt.Color;
import java.awt.Cursor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;


/**
 *
 * @author lucas
 */
public class TelaEditarParaPaciente extends javax.swing.JFrame {

    /**
     * Creates new form TelaEditarParaPaciente
     */
    public TelaEditarParaPaciente() {
        initComponents();
        
        setExtendedState(TelaEditarParaPaciente.MAXIMIZED_BOTH);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        PainelPrincipal = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        PanelComDados = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        nometxt = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        emailtxt = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        senhapass = new javax.swing.JPasswordField();
        jLabel21 = new javax.swing.JLabel();
        datanasctxt = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        teltxt = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        cpftxt = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        enderecotxt = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        bairrotxt = new javax.swing.JTextField();
        cidadetxt = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        cnstxt = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        sexocbx = new javax.swing.JComboBox<>();
        jLabel29 = new javax.swing.JLabel();
        uftxt = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        numtxt = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        ceptxt = new javax.swing.JTextField();
        jCheckBox1 = new javax.swing.JCheckBox();
        jLabel32 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        updateBottom = new javax.swing.JButton();
        SelectButtom = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        FaleConosco = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        vacinamais1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 153, 204));

        PainelPrincipal.setBackground(new java.awt.Color(255, 255, 255));
        PainelPrincipal.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                PainelPrincipalMouseEntered(evt);
            }
        });
        PainelPrincipal.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                PainelPrincipalComponentResized(evt);
            }
        });

        jButton6.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jButton6.setText("| Cadastrar");
        jButton6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton6MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton6MouseExited(evt);
            }
        });
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jButton7.setText("| Editar");
        jButton7.setEnabled(false);
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap(14, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(15, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        PanelComDados.setBackground(new java.awt.Color(255, 255, 255));
        PanelComDados.addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentRemoved(java.awt.event.ContainerEvent evt) {
                PanelComDadosComponentRemoved(evt);
            }
        });
        PanelComDados.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                PanelComDadosComponentResized(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Dialog", 1, 20)); // NOI18N
        jLabel6.setText("Nome Completo:*");

        nometxt.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        nometxt.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel19.setFont(new java.awt.Font("Dialog", 1, 20)); // NOI18N
        jLabel19.setText("E-mail:*");

        emailtxt.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        emailtxt.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel20.setFont(new java.awt.Font("Dialog", 1, 20)); // NOI18N
        jLabel20.setText("Senha:*");

        senhapass.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        senhapass.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        senhapass.setEchoChar('\u2665');

        jLabel21.setFont(new java.awt.Font("Dialog", 1, 20)); // NOI18N
        jLabel21.setText("Data de Nascimento:*");

        datanasctxt.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        datanasctxt.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel22.setFont(new java.awt.Font("Dialog", 1, 20)); // NOI18N
        jLabel22.setText("Telefone de Contato:*");

        teltxt.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        teltxt.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel23.setFont(new java.awt.Font("Dialog", 1, 20)); // NOI18N
        jLabel23.setText("CPF:*");

        cpftxt.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        cpftxt.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel24.setFont(new java.awt.Font("Dialog", 1, 20)); // NOI18N
        jLabel24.setText("Endereço:*");

        enderecotxt.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        enderecotxt.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        enderecotxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                enderecotxtActionPerformed(evt);
            }
        });

        jLabel25.setFont(new java.awt.Font("Dialog", 1, 20)); // NOI18N
        jLabel25.setText("Bairro:*");

        jLabel26.setFont(new java.awt.Font("Dialog", 1, 20)); // NOI18N
        jLabel26.setText("Cidade:*");

        bairrotxt.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        bairrotxt.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        cidadetxt.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        cidadetxt.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel27.setFont(new java.awt.Font("Dialog", 1, 20)); // NOI18N
        jLabel27.setText("CNS:*");

        cnstxt.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        cnstxt.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel28.setFont(new java.awt.Font("Dialog", 1, 20)); // NOI18N
        jLabel28.setText("Sexo:*");

        sexocbx.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        sexocbx.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione...", "M", "F" }));
        sexocbx.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        sexocbx.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sexocbxActionPerformed(evt);
            }
        });

        jLabel29.setFont(new java.awt.Font("Dialog", 1, 20)); // NOI18N
        jLabel29.setText("UF:*");
        jLabel29.setToolTipText("");

        uftxt.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        uftxt.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel30.setFont(new java.awt.Font("Dialog", 1, 20)); // NOI18N
        jLabel30.setText("Nº:*");

        numtxt.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        numtxt.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel31.setFont(new java.awt.Font("Dialog", 1, 20)); // NOI18N
        jLabel31.setText("CEP:*");

        ceptxt.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        ceptxt.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jCheckBox1.setBackground(new java.awt.Color(255, 255, 255));
        jCheckBox1.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        jCheckBox1.setText("Mostrar Senha");
        jCheckBox1.setBorder(null);
        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });

        jLabel32.setBackground(new java.awt.Color(204, 204, 204));
        jLabel32.setFont(new java.awt.Font("Dialog", 2, 14)); // NOI18N
        jLabel32.setText("campos com ' * ' devem ser preenchidos");
        jLabel32.setOpaque(true);
        jLabel32.setRequestFocusEnabled(false);

        jLabel2.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 153, 102));
        jLabel2.setText("Editar dados pessoais do Paciente");

        updateBottom.setBackground(new java.awt.Color(0, 153, 204));
        updateBottom.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        updateBottom.setText("Atualizar");
        updateBottom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBottomActionPerformed(evt);
            }
        });

        SelectButtom.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        SelectButtom.setText("Pesquisar CPF");
        SelectButtom.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                SelectButtomMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                SelectButtomMouseExited(evt);
            }
        });
        SelectButtom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelectButtomActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelComDadosLayout = new javax.swing.GroupLayout(PanelComDados);
        PanelComDados.setLayout(PanelComDadosLayout);
        PanelComDadosLayout.setHorizontalGroup(
            PanelComDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelComDadosLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(PanelComDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelComDadosLayout.createSequentialGroup()
                        .addGroup(PanelComDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, PanelComDadosLayout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(nometxt))
                            .addGroup(PanelComDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelComDadosLayout.createSequentialGroup()
                                    .addComponent(jLabel19)
                                    .addGap(12, 12, 12)
                                    .addComponent(emailtxt, javax.swing.GroupLayout.PREFERRED_SIZE, 416, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(PanelComDadosLayout.createSequentialGroup()
                                    .addComponent(jLabel20)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(senhapass, javax.swing.GroupLayout.PREFERRED_SIZE, 415, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(4, 4, 4)
                        .addComponent(jCheckBox1))
                    .addGroup(PanelComDadosLayout.createSequentialGroup()
                        .addGroup(PanelComDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, PanelComDadosLayout.createSequentialGroup()
                                .addComponent(jLabel28)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(sexocbx, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(datanasctxt))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, PanelComDadosLayout.createSequentialGroup()
                                .addComponent(jLabel22)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(teltxt))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, PanelComDadosLayout.createSequentialGroup()
                                .addComponent(jLabel27)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(cnstxt))
                            .addGroup(PanelComDadosLayout.createSequentialGroup()
                                .addComponent(jLabel26)
                                .addGap(18, 18, 18)
                                .addComponent(cidadetxt, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel29)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(uftxt))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, PanelComDadosLayout.createSequentialGroup()
                                .addGroup(PanelComDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel31)
                                    .addComponent(jLabel30))
                                .addGap(18, 18, 18)
                                .addGroup(PanelComDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(ceptxt, javax.swing.GroupLayout.DEFAULT_SIZE, 95, Short.MAX_VALUE)
                                    .addComponent(numtxt))
                                .addGap(18, 18, 18)
                                .addGroup(PanelComDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(PanelComDadosLayout.createSequentialGroup()
                                        .addComponent(jLabel24)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(enderecotxt, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(PanelComDadosLayout.createSequentialGroup()
                                        .addComponent(jLabel25)
                                        .addGap(18, 18, 18)
                                        .addComponent(bairrotxt)))))
                        .addGap(140, 140, 140)
                        .addComponent(updateBottom, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel2)
                    .addGroup(PanelComDadosLayout.createSequentialGroup()
                        .addGroup(PanelComDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(PanelComDadosLayout.createSequentialGroup()
                                .addComponent(jLabel23)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cpftxt, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel32))
                        .addGap(18, 18, 18)
                        .addComponent(SelectButtom)))
                .addContainerGap(247, Short.MAX_VALUE))
        );
        PanelComDadosLayout.setVerticalGroup(
            PanelComDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelComDadosLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel2)
                .addGroup(PanelComDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(PanelComDadosLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel32)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(PanelComDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel23)
                            .addComponent(cpftxt, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(PanelComDadosLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(SelectButtom, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelComDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nometxt, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelComDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(emailtxt, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel19))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelComDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(senhapass, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jCheckBox1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelComDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel28)
                    .addComponent(sexocbx, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel21)
                    .addComponent(datanasctxt, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelComDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(teltxt, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelComDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelComDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel31)
                        .addComponent(ceptxt, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel24))
                    .addComponent(enderecotxt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelComDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel30)
                    .addComponent(numtxt, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel25)
                    .addComponent(bairrotxt, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(PanelComDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel29)
                    .addComponent(uftxt, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel26)
                    .addComponent(cidadetxt, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelComDadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel27)
                    .addComponent(cnstxt, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(updateBottom))
                .addGap(255, 255, 255))
        );

        jPanel3.setBackground(new java.awt.Color(0, 153, 204));
        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        FaleConosco.setBackground(new java.awt.Color(0, 153, 153));
        FaleConosco.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        FaleConosco.setForeground(new java.awt.Color(255, 255, 255));
        FaleConosco.setText("Fale Conosco");
        FaleConosco.setContentAreaFilled(false);
        FaleConosco.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                FaleConoscoMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                FaleConoscoMouseEntered(evt);
            }
        });
        FaleConosco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FaleConoscoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(FaleConosco)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(FaleConosco))
        );

        javax.swing.GroupLayout PainelPrincipalLayout = new javax.swing.GroupLayout(PainelPrincipal);
        PainelPrincipal.setLayout(PainelPrincipalLayout);
        PainelPrincipalLayout.setHorizontalGroup(
            PainelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PainelPrincipalLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(PainelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PainelPrincipalLayout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(PainelPrincipalLayout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(PanelComDados, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(25, 227, Short.MAX_VALUE))))
        );
        PainelPrincipalLayout.setVerticalGroup(
            PainelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PainelPrincipalLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PainelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(PainelPrincipalLayout.createSequentialGroup()
                        .addComponent(PanelComDados, javax.swing.GroupLayout.PREFERRED_SIZE, 478, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 75, Short.MAX_VALUE)))
                .addContainerGap())
        );

        jPanel4.setBackground(new java.awt.Color(0, 204, 255));

        vacinamais1.setFont(new java.awt.Font("Bauhaus 93", 0, 85)); // NOI18N
        vacinamais1.setForeground(new java.awt.Color(255, 255, 255));
        vacinamais1.setText("Vacina +");
        vacinamais1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                vacinamais1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                vacinamais1MouseEntered(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(vacinamais1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(0, 21, Short.MAX_VALUE)
                .addComponent(vacinamais1, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PainelPrincipal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(PainelPrincipal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton6MouseEntered
        Color cor = new Color(0,153,204);

        jButton6.setBackground(cor);

    }//GEN-LAST:event_jButton6MouseEntered

    private void jButton6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton6MouseExited
        Color cor2 = new Color(255,255,255);
        jButton6.setBackground(cor2);
        
    }//GEN-LAST:event_jButton6MouseExited

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed

        TelaCadastrarParaPaciente cada = new TelaCadastrarParaPaciente();
        cada.setVisible(true);
        dispose();

    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed

    }//GEN-LAST:event_jButton7ActionPerformed

    private void FaleConoscoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FaleConoscoMouseClicked
  
    }//GEN-LAST:event_FaleConoscoMouseClicked

    private void FaleConoscoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FaleConoscoMouseEntered
        FaleConosco.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_FaleConoscoMouseEntered

    private void enderecotxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_enderecotxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_enderecotxtActionPerformed

    private void sexocbxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sexocbxActionPerformed

    }//GEN-LAST:event_sexocbxActionPerformed

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        if (jCheckBox1.isSelected()) {
            senhapass.setEchoChar((char)0); //password = JPasswordField
        } else {
            senhapass.setEchoChar('♥');
        }
    }//GEN-LAST:event_jCheckBox1ActionPerformed

    private void updateBottomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateBottomActionPerformed
        try {
            Connection conexao = null;
            PreparedStatement statement = null;

            String url = "jdbc:mysql://localhost:3355/db_vacinamais";
            String usuario = "root";
            String senha = "usbw";

            conexao = DriverManager.getConnection(url, usuario, senha);

            String sql = "UPDATE paciente SET nome_paciente = ?,email_paciente = ? ,senha_paciente = ?,nascimento_paciente = ?,tel_paciente = ?,\n" +
            "cpf_paciente = ?,sexo_paciente = ? ,endereco_paciente = ? ,numero_casa_paciente = ?,bairro_paciente = ? ,cep_paciente = ? ,cidade_paciente = ? ,uf_paciente = ?,cns_paciente = ? where cpf_paciente = ?";
            
            statement = conexao.prepareStatement(sql);
            statement.setString(1, nometxt.getText());
            statement.setString(2, emailtxt.getText());
            statement.setString(3, senhapass.getText());
            statement.setString(4, datanasctxt.getText());
            statement.setString(5, teltxt.getText());
            statement.setString(6, cpftxt.getText());
            statement.setString(7, sexocbx.getSelectedItem().toString());
            statement.setString(8, enderecotxt.getText());
            statement.setString(9, numtxt.getText());
            statement.setString(10, bairrotxt.getText());
            statement.setString(11, ceptxt.getText());
            statement.setString(12, cidadetxt.getText());
            statement.setString(13, uftxt.getText());
            statement.setString(14, cnstxt.getText());
            statement.setString(15, cpftxt.getText());

            int linhasAfetadas = statement.executeUpdate();

            if(linhasAfetadas > 0){

                JOptionPane.showMessageDialog(rootPane,"Dados atualizados com sucesso");

            }else {

                JOptionPane.showMessageDialog(rootPane,"Erro ao atualizar dados");

            }

            if(statement != null){
                statement.close();
            }
            if(statement != null){
                conexao.close();
            }
        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(rootPane,"Alerta! Algum Campo obrigatorio vazio: " + ex);

        }

    }//GEN-LAST:event_updateBottomActionPerformed

    private void PanelComDadosComponentRemoved(java.awt.event.ContainerEvent evt) {//GEN-FIRST:event_PanelComDadosComponentRemoved

    }//GEN-LAST:event_PanelComDadosComponentRemoved

    private void PanelComDadosComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_PanelComDadosComponentResized

    }//GEN-LAST:event_PanelComDadosComponentResized

    private void PainelPrincipalMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PainelPrincipalMouseEntered

    }//GEN-LAST:event_PainelPrincipalMouseEntered

    private void PainelPrincipalComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_PainelPrincipalComponentResized
       
             nometxt.enable(false);
             emailtxt.enable(false);
             senhapass.enable(false);
             datanasctxt.enable(false);
             teltxt.enable(false);             
             sexocbx.enable(false);
             enderecotxt.enable(false);
             numtxt.enable(false);
             bairrotxt.enable(false);
             ceptxt.enable(false);
             cidadetxt.enable(false);
             uftxt.enable(false);
             cnstxt.enable(false);
 
    }//GEN-LAST:event_PainelPrincipalComponentResized

    private void SelectButtomMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SelectButtomMouseEntered

        Color cor = new Color(0,153,204);

        SelectButtom.setBackground(cor);

    }//GEN-LAST:event_SelectButtomMouseEntered

    private void SelectButtomMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SelectButtomMouseExited

        Color cor = new Color(255,255,255);

        SelectButtom.setBackground(cor);
    }//GEN-LAST:event_SelectButtomMouseExited

    private void SelectButtomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SelectButtomActionPerformed
            try {
             
           Connection conexao = null;
           PreparedStatement statement = null;

           String url = "jdbc:mysql://localhost:3355/db_vacinamais";
           String usuario = "root";
           String senha = "usbw";
           
           conexao = DriverManager.getConnection(url, usuario, senha);
             
            String sql = "select * from paciente where cpf_paciente = ?";
            
            statement = conexao.prepareStatement(sql);
            
            statement.setString(1, cpftxt.getText());
             
            ResultSet resultado = statement.executeQuery();
            
            while(resultado.next()){
                         
            nometxt.setText(resultado.getString("nome_paciente"));
            emailtxt.setText(resultado.getString("email_paciente"));
            senhapass.setText(resultado.getString("senha_paciente"));
            datanasctxt.setText(resultado.getString("nascimento_paciente"));
            teltxt.setText(resultado.getString("tel_paciente"));
            sexocbx.setSelectedItem(resultado.getString("sexo_paciente"));
            enderecotxt.setText(resultado.getString("endereco_paciente"));
            numtxt.setText(resultado.getString("numero_casa_paciente"));
            bairrotxt.setText( resultado.getString("bairro_paciente"));
            ceptxt.setText(resultado.getString("cep_paciente"));
            cidadetxt.setText(resultado.getString("cidade_paciente"));
            uftxt.setText(resultado.getString("uf_paciente"));
            cnstxt.setText(resultado.getString("cns_paciente"));

            }
            
           
            
           if (resultado.isAfterLast() == true) {
            
            
          
        
  
             JOptionPane.showMessageDialog(rootPane,"Sucesso!");
             
             nometxt.enable(true);
             emailtxt.enable(true);
             senhapass.enable(true);
             datanasctxt.enable(true);
             teltxt.enable(true);             
             sexocbx.enable(true);
             enderecotxt.enable(true);
             numtxt.enable(true);
             bairrotxt.enable(true);
             ceptxt.enable(true);
             cidadetxt.enable(true);
             uftxt.enable(true);
             cnstxt.enable(true);
            
            
            } else if (resultado.isBeforeFirst() == false){
            
          JOptionPane.showMessageDialog(rootPane,"CPF Nao encontrado");
          
          nometxt.enable(false);
             emailtxt.enable(false);
             senhapass.enable(false);
             datanasctxt.enable(false);
             teltxt.enable(false);             
             sexocbx.enable(false);
             enderecotxt.enable(false);
             numtxt.enable(false);
             bairrotxt.enable(false);
             ceptxt.enable(false);
             cidadetxt.enable(false);
             uftxt.enable(false);
             cnstxt.enable(false);
             
             nometxt.setText("");
            emailtxt.setText("");
            senhapass.setText("");
            datanasctxt.setText("");
            teltxt.setText("");
            sexocbx.setSelectedItem("");
            enderecotxt.setText("");
            numtxt.setText("");
            bairrotxt.setText( "");
            ceptxt.setText("");
            cidadetxt.setText("");
            uftxt.setText("");
            cnstxt.setText("");
         
            }
   
           statement.close();
            conexao.close();
            
        } catch (SQLException ex) {
            
            JOptionPane.showMessageDialog(rootPane," ALGO ESTÁ ERRADO!: " + ex, "Erro404" ,JOptionPane.ERROR_MESSAGE);
            
        }
       
    }//GEN-LAST:event_SelectButtomActionPerformed

    private void FaleConoscoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FaleConoscoActionPerformed

        TelaAjudaBotao ajuda = new TelaAjudaBotao();
        ajuda.setVisible(true);     
    }//GEN-LAST:event_FaleConoscoActionPerformed

    private void vacinamais1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_vacinamais1MouseClicked
        ATelaInicialVacinamais tela = new ATelaInicialVacinamais();
        tela.setVisible(true);
        dispose();
    }//GEN-LAST:event_vacinamais1MouseClicked

    private void vacinamais1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_vacinamais1MouseEntered

        vacinamais1.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_vacinamais1MouseEntered

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaEditarParaPaciente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaEditarParaPaciente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaEditarParaPaciente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaEditarParaPaciente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaEditarParaPaciente().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton FaleConosco;
    private javax.swing.JPanel PainelPrincipal;
    private javax.swing.JPanel PanelComDados;
    private javax.swing.JButton SelectButtom;
    private javax.swing.JTextField bairrotxt;
    private javax.swing.JTextField ceptxt;
    private javax.swing.JTextField cidadetxt;
    private javax.swing.JTextField cnstxt;
    private javax.swing.JTextField cpftxt;
    private javax.swing.JTextField datanasctxt;
    private javax.swing.JTextField emailtxt;
    private javax.swing.JTextField enderecotxt;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JTextField nometxt;
    private javax.swing.JTextField numtxt;
    private javax.swing.JPasswordField senhapass;
    private javax.swing.JComboBox<String> sexocbx;
    private javax.swing.JTextField teltxt;
    private javax.swing.JTextField uftxt;
    private javax.swing.JButton updateBottom;
    private javax.swing.JLabel vacinamais1;
    // End of variables declaration//GEN-END:variables
}
