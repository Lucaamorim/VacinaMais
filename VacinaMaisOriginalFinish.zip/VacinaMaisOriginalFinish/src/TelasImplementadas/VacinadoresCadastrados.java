/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package TelasImplementadas;

import java.awt.Color;
import java.awt.Cursor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author lucas
 */
public class VacinadoresCadastrados extends javax.swing.JFrame {

    /**
     * Creates new form VacinadoresCadastrados
     */
    public VacinadoresCadastrados() {
        initComponents();
    }

    public void MetodoTable(String sql) {
        
        try {
                        
            Connection con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3355/db_vacinamais", "root", "usbw");
            PreparedStatement banco = (PreparedStatement)con.prepareStatement(sql);
            banco.execute(); 
            
            ResultSet resultado = banco.executeQuery(sql);
            
            DefaultTableModel model =(DefaultTableModel) TabelaPaciente2.getModel();
            model.setNumRows(0);
            
            while(resultado.next())
            {
                model.addRow(new Object[]
                {
                    //retorna os dados da tabela do BD, cada campo e um coluna.
                    
                    resultado.getString("nome_vacinador"),
                    resultado.getString("email_vacinador"),
                    resultado.getString("senha_vacinador"),
                    resultado.getString("nascimento_vacinador"),
                    resultado.getString("tel_vacinador"),
                    resultado.getString("cpf_vacinador"),
                    resultado.getString("sexo_vacinador"),
                    resultado.getString("endereco_vacinador"),
                    resultado.getString("numero_casa_vacinador"),
                    resultado.getString("bairro_vacinador"),
                    resultado.getString("cep_vacinador"),
                    resultado.getString("cidade_vacinador"),
                    resultado.getString("uf_vacinador"),
                    resultado.getString("cns_vacinador"),
                    resultado.getString("cbo_vacinador")
                    
                    
                });
            }
            
            if (model.getRowCount() == 0){
                
            JOptionPane.showMessageDialog(rootPane,"Nenhum CPF Encontrado");
            
            }
            banco.close();
            con.close();
            
        } catch (SQLException ex) {
            
            JOptionPane.showMessageDialog(rootPane," Alerta! Campo vazio / Favor preencher o campo apenas com Números" + ex);
            
        }
     }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        vacinamais = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TabelaPaciente2 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        SelectButtom = new javax.swing.JButton();
        DeleteButtom = new javax.swing.JButton();
        cpfVacinadortxt = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        ATTtabela = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 153, 204));

        jPanel2.setBackground(new java.awt.Color(0, 204, 255));

        jButton1.setBackground(new java.awt.Color(0, 204, 255));
        jButton1.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 0, 51));
        jButton1.setText("Sair");
        jButton1.setBorderPainted(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        vacinamais.setFont(new java.awt.Font("Bauhaus 93", 0, 85)); // NOI18N
        vacinamais.setForeground(new java.awt.Color(255, 255, 255));
        vacinamais.setText("Vacina +");
        vacinamais.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                vacinamaisMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                vacinamaisMouseEntered(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(vacinamais)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(14, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(vacinamais, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                jPanel3ComponentResized(evt);
            }
        });

        TabelaPaciente2.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        TabelaPaciente2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nome", "Email", "Senha", "Data de Nascimento", "Telefone", "CPF", "Sexo", "Endereço", "Numero", "Bairro", "CEP", "Cidade", "UF", "CNS", "CBO"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TabelaPaciente2.setColumnSelectionAllowed(true);
        TabelaPaciente2.getTableHeader().setReorderingAllowed(false);
        TabelaPaciente2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabelaPaciente2MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TabelaPaciente2);
        TabelaPaciente2.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);

        jLabel2.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 153, 102));
        jLabel2.setText("Vacinadores Cadastrados");

        jPanel6.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        SelectButtom.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        SelectButtom.setText("Pesquisar");
        SelectButtom.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                SelectButtomMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                SelectButtomMouseExited(evt);
            }
        });
        SelectButtom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelectButtomActionPerformed(evt);
            }
        });

        DeleteButtom.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        DeleteButtom.setText("Excluir");
        DeleteButtom.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                DeleteButtomMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                DeleteButtomMouseExited(evt);
            }
        });
        DeleteButtom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteButtomActionPerformed(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("Dialog", 1, 11)); // NOI18N
        jLabel18.setText("CPF do Vacinador");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(SelectButtom, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18))
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cpfVacinadortxt, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(55, Short.MAX_VALUE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(DeleteButtom, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30))))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cpfVacinadortxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SelectButtom)
                    .addComponent(DeleteButtom))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        ATTtabela.setBackground(new java.awt.Color(51, 204, 255));
        ATTtabela.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        ATTtabela.setText("Atualizar Tabela");
        ATTtabela.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        ATTtabela.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ATTtabelaActionPerformed(evt);
            }
        });

        jLabel3.setText("Clique no paciente para Alterar seus Dados!");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 546, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(ATTtabela, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)))
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(jLabel2)
                        .addGap(27, 27, 27)
                        .addComponent(jLabel3))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(ATTtabela)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 256, Short.MAX_VALUE)
                .addGap(26, 26, 26))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(28, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        TelaEditarProfissional edit = new TelaEditarProfissional();
        edit.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void TabelaPaciente2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabelaPaciente2MouseClicked

        TelaEditarProfissional pac =  new TelaEditarProfissional();

        int linha = TabelaPaciente2.getSelectedRow();

        pac.setVisible(true);
        dispose();

        cpfVacinadortxt.setText(TabelaPaciente2.getValueAt(linha,6).toString());
        pac.setNometxt(TabelaPaciente2.getValueAt(linha,1).toString());
        pac.setEmailtxt(TabelaPaciente2.getValueAt(linha,2).toString());
        pac.setSenhapass(TabelaPaciente2.getValueAt(linha,3).toString());
        pac.setDatanasctxt(TabelaPaciente2.getValueAt(linha,4).toString());
        pac.setTeltxt(TabelaPaciente2.getValueAt(linha,5).toString());
        pac.setCpftxt(TabelaPaciente2.getValueAt(linha,6).toString());
        pac.setSexocbx(TabelaPaciente2.getValueAt(linha,7).toString());
        pac.setEnderecotxt(TabelaPaciente2.getValueAt(linha,8).toString());
        pac.setNumtxt(TabelaPaciente2.getValueAt(linha,9).toString());
        pac.setBairrotxt(TabelaPaciente2.getValueAt(linha,10).toString());
        pac.setCeptxt(TabelaPaciente2.getValueAt(linha,11).toString());
        pac.setCidadetxt(TabelaPaciente2.getValueAt(linha,12).toString());
        pac.setUftxt(TabelaPaciente2.getValueAt(linha,13).toString());
        pac.setCnstxt(TabelaPaciente2.getValueAt(linha,14).toString());
        pac.setCbotxt(TabelaPaciente2.getValueAt(linha,15).toString());

    }//GEN-LAST:event_TabelaPaciente2MouseClicked

    private void SelectButtomMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SelectButtomMouseEntered

        Color cor = new Color(0,153,204);

        SelectButtom.setBackground(cor);

    }//GEN-LAST:event_SelectButtomMouseEntered

    private void SelectButtomMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SelectButtomMouseExited

        Color cor = new Color(255,255,255);

        SelectButtom.setBackground(cor);
    }//GEN-LAST:event_SelectButtomMouseExited

    private void SelectButtomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SelectButtomActionPerformed

        this.MetodoTable("select * from vacinador where cpf_vacinador =" + this.cpfVacinadortxt.getText());
    }//GEN-LAST:event_SelectButtomActionPerformed

    private void DeleteButtomMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DeleteButtomMouseEntered
        Color cor = new Color(0,153,204);

        DeleteButtom.setBackground(cor);

    }//GEN-LAST:event_DeleteButtomMouseEntered

    private void DeleteButtomMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DeleteButtomMouseExited

        Color cor = new Color(255,255,255);

        DeleteButtom.setBackground(cor);

    }//GEN-LAST:event_DeleteButtomMouseExited

    private void DeleteButtomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteButtomActionPerformed

        Connection conexao = null;
        PreparedStatement statement = null;

        String url = "jdbc:mysql://localhost:3355/db_vacinamais";
        String usuario = "root";
        String senha = "usbw";

        try {
            conexao = DriverManager.getConnection(url, usuario, senha);
            String sql = "delete from vacinador where cpf_paciente = ?";

            statement = conexao.prepareStatement(sql);
            statement.setString(1, cpfVacinadortxt.getText());

            int linhasAfetadas = statement.executeUpdate();

            if(linhasAfetadas > 0){
                JOptionPane.showMessageDialog(rootPane,"Dados excluidos com sucesso");
                this.MetodoTable("SELECT * FROM vacinador");
            }else {
                JOptionPane.showMessageDialog(rootPane,"Erro ao Deletar dados");
            }

            // TODO add your handling code here:
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane,"Alerta! Campo vazio / Favor preencher o campo apenas com Números");
        } finally {
            try{
                if(statement != null){
                    statement.close();
                }
                if(statement != null){
                    conexao.close();
                }
            }   catch (SQLException ex) {

                JOptionPane.showMessageDialog(rootPane,"Erro ao fechar conexão " + ex.getMessage());

            }
        }
    }//GEN-LAST:event_DeleteButtomActionPerformed

    private void ATTtabelaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ATTtabelaActionPerformed
        this.MetodoTable("SELECT * FROM vacinador");
    }//GEN-LAST:event_ATTtabelaActionPerformed

    private void jPanel3ComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_jPanel3ComponentResized

        this.MetodoTable("SELECT * FROM vacinador ORDER BY id_vacinador;");

    }//GEN-LAST:event_jPanel3ComponentResized

    private void vacinamaisMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_vacinamaisMouseClicked
        ATelaInicialVacinamais tela = new ATelaInicialVacinamais();
        tela.setVisible(true);
        dispose();
    }//GEN-LAST:event_vacinamaisMouseClicked

    private void vacinamaisMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_vacinamaisMouseEntered

        vacinamais.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_vacinamaisMouseEntered

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VacinadoresCadastrados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VacinadoresCadastrados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VacinadoresCadastrados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VacinadoresCadastrados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VacinadoresCadastrados().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ATTtabela;
    private javax.swing.JButton DeleteButtom;
    private javax.swing.JButton SelectButtom;
    private javax.swing.JTable TabelaPaciente2;
    private javax.swing.JTextField cpfVacinadortxt;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel vacinamais;
    // End of variables declaration//GEN-END:variables
}
