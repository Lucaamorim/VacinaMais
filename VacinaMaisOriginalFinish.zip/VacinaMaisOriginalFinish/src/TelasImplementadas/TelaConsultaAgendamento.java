/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package TelasImplementadas;

import java.awt.Cursor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author lucas
 */
public class TelaConsultaAgendamento extends javax.swing.JFrame {

    /**
     * Creates new form TelaConsultaAgendamento
     */
    public TelaConsultaAgendamento() {
        initComponents();
        setExtendedState(TelaConsultaAgendamento.MAXIMIZED_BOTH);
    }
    
private void gerarCPF(String sql){

        try {
            Connection con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3355/db_vacinamais", "root", "usbw");
            PreparedStatement banco = (PreparedStatement)con.prepareStatement(sql);
            banco.execute(); 
            
            ResultSet resultado = banco.executeQuery(sql);

            pesqCPF.setText(resultado.getString("cpf_paciente"));
        
        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(rootPane,"Nenhum CPF Selecionado"+ ex);
        }
       
}
    
private void MetodoTable(String sql) {
    
        try {
            
            Connection con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3355/db_vacinamais", "root", "usbw");
            PreparedStatement banco = (PreparedStatement)con.prepareStatement(sql);
            banco.execute(); 
            
            ResultSet resultado = banco.executeQuery(sql);
            
            DefaultTableModel model =(DefaultTableModel) TableCadastros.getModel();
            model.setNumRows(0);
            
            while(resultado.next())
            {
                model.addRow(new Object[]
                {
                    resultado.getString("id_agendamento"),
                    resultado.getString("cpf_paciente"),
                    resultado.getString("nome_vacina"),
                    resultado.getString("dose"),
                    resultado.getString("nome_fantasia_estabelecimento"),
                    resultado.getString("data_agendamento"),
   
                });
            }
            
           if (model.getRowCount() == 0){
                
            JOptionPane.showMessageDialog(rootPane,"Nenhum CPF Encontrado");
            
            }
            
            banco.close();
            con.close();
            
        } catch (SQLException ex) {
            
            JOptionPane.showMessageDialog(rootPane, "Erro ao inserir" + ex);
            
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        vacinamais1 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        painelmenu = new javax.swing.JPanel();
        agendese = new javax.swing.JButton();
        FaleConosco = new javax.swing.JButton();
        tirarCartao = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        TableCadastros = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        pesqCPF = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(0, 153, 204));

        jPanel1.setBackground(new java.awt.Color(0, 204, 255));

        vacinamais1.setFont(new java.awt.Font("Bauhaus 93", 0, 85)); // NOI18N
        vacinamais1.setForeground(new java.awt.Color(255, 255, 255));
        vacinamais1.setText("Vacina +");
        vacinamais1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                vacinamais1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                vacinamais1MouseEntered(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(vacinamais1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 25, Short.MAX_VALUE)
                .addComponent(vacinamais1, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));

        painelmenu.setBackground(new java.awt.Color(0, 153, 204));
        painelmenu.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        painelmenu.setRequestFocusEnabled(false);

        agendese.setBackground(new java.awt.Color(0, 153, 153));
        agendese.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        agendese.setForeground(new java.awt.Color(255, 255, 255));
        agendese.setText("Agendar");
        agendese.setBorderPainted(false);
        agendese.setContentAreaFilled(false);
        agendese.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        agendese.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                agendeseMouseEntered(evt);
            }
        });
        agendese.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agendeseActionPerformed(evt);
            }
        });

        FaleConosco.setBackground(new java.awt.Color(0, 153, 153));
        FaleConosco.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        FaleConosco.setForeground(new java.awt.Color(255, 255, 255));
        FaleConosco.setText("Fale Conosco");
        FaleConosco.setContentAreaFilled(false);
        FaleConosco.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                FaleConoscoMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                FaleConoscoMouseEntered(evt);
            }
        });
        FaleConosco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FaleConoscoActionPerformed(evt);
            }
        });

        tirarCartao.setBackground(new java.awt.Color(0, 153, 153));
        tirarCartao.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        tirarCartao.setForeground(new java.awt.Color(255, 255, 255));
        tirarCartao.setText("Tirar seu Cartão de Vacina");
        tirarCartao.setContentAreaFilled(false);
        tirarCartao.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                tirarCartaoMouseEntered(evt);
            }
        });
        tirarCartao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tirarCartaoActionPerformed(evt);
            }
        });

        jButton4.setBackground(new java.awt.Color(0, 153, 204));
        jButton4.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Serviços para Vacinadores");
        jButton4.setToolTipText("");
        jButton4.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jButton4.setBorderPainted(false);
        jButton4.setContentAreaFilled(false);
        jButton4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton4MouseEntered(evt);
            }
        });
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout painelmenuLayout = new javax.swing.GroupLayout(painelmenu);
        painelmenu.setLayout(painelmenuLayout);
        painelmenuLayout.setHorizontalGroup(
            painelmenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelmenuLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(agendese)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tirarCartao)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(FaleConosco))
        );
        painelmenuLayout.setVerticalGroup(
            painelmenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, painelmenuLayout.createSequentialGroup()
                .addGap(0, 3, Short.MAX_VALUE)
                .addGroup(painelmenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(agendese)
                    .addComponent(FaleConosco)
                    .addComponent(tirarCartao)
                    .addComponent(jButton4)))
        );

        TableCadastros.setBorder(new javax.swing.border.MatteBorder(null));
        TableCadastros.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "iD", "CPF", "Vacina ", "Dose a ser tomada", "Data Marcada", "Estabelecimento"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TableCadastros.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TableCadastrosMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(TableCadastros);

        jButton1.setText("Cancelar Agendamento");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(102, 102, 102));
        jLabel2.setText("CPF a ser consultado:");

        pesqCPF.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        pesqCPF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pesqCPFActionPerformed(evt);
            }
        });

        jButton2.setText("Pesquisar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel1)
                        .addGap(578, 578, 578))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(painelmenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pesqCPF, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 751, Short.MAX_VALUE)
                        .addComponent(jButton1)
                        .addContainerGap())))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(painelmenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jLabel2)
                    .addComponent(pesqCPF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(254, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void agendeseMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_agendeseMouseEntered
        agendese.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_agendeseMouseEntered

    private void FaleConoscoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FaleConoscoMouseClicked

    }//GEN-LAST:event_FaleConoscoMouseClicked

    private void FaleConoscoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FaleConoscoMouseEntered
        FaleConosco.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_FaleConoscoMouseEntered

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        
    
            String text = pesqCPF.getText();
            
            if (text.equals("admvacinador*")) {
                
                MetodoTable("SELECT * FROM agendamento ORDER BY nome_vacina");
                
            } else if (text.length() == 11){
                
                MetodoTable("select * from agendamento where cpf_paciente = " + pesqCPF.getText());
                
            } else if (text.length() != 11){
                
                JOptionPane.showMessageDialog(rootPane, "Isso Não é um CPF!");
                
            }
       
        
      
       
    }//GEN-LAST:event_jButton2ActionPerformed

    private void TableCadastrosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TableCadastrosMouseClicked
        
        int linha = TableCadastros.getSelectedRow();
        pesqCPF.setText(TableCadastros.getValueAt(linha,0).toString());
            
    }//GEN-LAST:event_TableCadastrosMouseClicked

    private void pesqCPFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pesqCPFActionPerformed
        
    }//GEN-LAST:event_pesqCPFActionPerformed

    private void agendeseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agendeseActionPerformed
        TelaAgendar agenda = new TelaAgendar();
        agenda.setVisible(true);
        dispose();
    }//GEN-LAST:event_agendeseActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
     
        try {
            Connection conexao = null;
            PreparedStatement statement = null;
            
            String url = "jdbc:mysql://localhost:3355/db_vacinamais";
            String usuario = "root";
            String senha = "usbw";
             
            conexao = DriverManager.getConnection(url, usuario, senha);
            
            String sql = "delete from agendamento where id_agendamento = ? ";
            
            
            statement = conexao.prepareStatement(sql);
            
            statement.setString(1, pesqCPF.getText());
            
            int linhasAfetadas = statement.executeUpdate();
            
            if(linhasAfetadas > 0 ){
                
                JOptionPane.showMessageDialog(rootPane, "Agendamento Cancelado");
 
                
            }else {
                
                JOptionPane.showMessageDialog(rootPane, "Erro ao deletar");
                
            }
            
            statement.close();
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Erro SQL: " + ex);
            
        }
        
        
        
        
        
        
        
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void FaleConoscoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FaleConoscoActionPerformed
        TelaAjudaBotao ajuda = new TelaAjudaBotao();

        ajuda.setVisible(true);

    }//GEN-LAST:event_FaleConoscoActionPerformed

    private void tirarCartaoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tirarCartaoMouseEntered
        tirarCartao.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_tirarCartaoMouseEntered

    private void tirarCartaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tirarCartaoActionPerformed

        TelaCartaodeVacina cartao = new TelaCartaodeVacina();
        cartao.setVisible(true);
        dispose();

    }//GEN-LAST:event_tirarCartaoActionPerformed

    private void jButton4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4MouseEntered

        jButton4.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_jButton4MouseEntered

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed

        int p;

        String input = JOptionPane.showInputDialog( "Codigo do Vacinador",JOptionPane.OK_CANCEL_OPTION);

        try {

            Connection conexao = null;
            PreparedStatement statement = null;

            String url = "jdbc:mysql://localhost:3355/db_vacinamais";
            String usuario = "root";
            String senha = "usbw";

            conexao = DriverManager.getConnection(url, usuario, senha);

            String sql = "select * from vacinador where cpf_vacinador = ?";

            statement = conexao.prepareStatement(sql);

            statement.setString(1, input);

            ResultSet resultado = statement.executeQuery();

            while(resultado.next()){

                resultado.findColumn("cpf_vacinador");

            }

            if (resultado.isAfterLast() == true) {

                TelaEscolhaCadastro tel = new  TelaEscolhaCadastro();
                tel.setVisible(true);
                dispose();
            } else if (resultado.isBeforeFirst() == false){

                JOptionPane.showMessageDialog(rootPane,"Acesso Negado!","Proibido",JOptionPane.ERROR_MESSAGE);

            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane,"Erro MySql: " + ex,"Fale Conosco",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void vacinamais1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_vacinamais1MouseClicked
        ATelaInicialVacinamais tela = new ATelaInicialVacinamais();
        tela.setVisible(true);
        dispose();
    }//GEN-LAST:event_vacinamais1MouseClicked

    private void vacinamais1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_vacinamais1MouseEntered

        vacinamais1.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_vacinamais1MouseEntered

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaConsultaAgendamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaConsultaAgendamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaConsultaAgendamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaConsultaAgendamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaConsultaAgendamento().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton FaleConosco;
    private javax.swing.JTable TableCadastros;
    private javax.swing.JButton agendese;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPanel painelmenu;
    private javax.swing.JTextField pesqCPF;
    private javax.swing.JButton tirarCartao;
    private javax.swing.JLabel vacinamais1;
    // End of variables declaration//GEN-END:variables
}
