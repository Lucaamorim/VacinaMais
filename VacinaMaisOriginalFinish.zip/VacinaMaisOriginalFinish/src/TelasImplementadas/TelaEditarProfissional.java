
package TelasImplementadas;

import java.awt.Color;
import java.awt.Cursor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author lucas
 */
public class TelaEditarProfissional extends javax.swing.JFrame {

    /**
     * Creates new form TelaEditarProfissional
     */
    public TelaEditarProfissional() {
        initComponents();
        setExtendedState(TelaEditarProfissional.MAXIMIZED_BOTH); 
    }
 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        vacinamais1 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        senhapass = new javax.swing.JPasswordField();
        jLabel11 = new javax.swing.JLabel();
        confsenhapass = new javax.swing.JPasswordField();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        nometxt = new javax.swing.JTextField();
        emailtxt = new javax.swing.JTextField();
        datanasctxt = new javax.swing.JTextField();
        teltxt = new javax.swing.JTextField();
        cpftxt = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        sexocbx = new javax.swing.JComboBox<>();
        enderecotxt = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        numtxt = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        bairrotxt = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        ceptxt = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        cidadetxt = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        uftxt = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        cnstxt = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        cbotxt = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        cadastrarVacinador = new javax.swing.JButton();
        DeletarVacinador = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        cpfVacinadortxt = new javax.swing.JTextField();
        painelmenu = new javax.swing.JPanel();
        Cadastrese = new javax.swing.JButton();
        FaleConosco = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 153, 204));

        jPanel7.setBackground(new java.awt.Color(0, 204, 255));

        vacinamais1.setFont(new java.awt.Font("Bauhaus 93", 0, 85)); // NOI18N
        vacinamais1.setForeground(new java.awt.Color(255, 255, 255));
        vacinamais1.setText("Vacina +");
        vacinamais1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                vacinamais1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                vacinamais1MouseEntered(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(vacinamais1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addGap(0, 32, Short.MAX_VALUE)
                .addComponent(vacinamais1, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                jPanel4ComponentResized(evt);
            }
        });

        jButton6.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jButton6.setText("| Cadastrar");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jButton7.setText("| Gerenciar");
        jButton7.setEnabled(false);
        jButton7.setSelected(true);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton7, javax.swing.GroupLayout.DEFAULT_SIZE, 207, Short.MAX_VALUE)
                    .addComponent(jButton6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel10.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel10.setText("Endereço:");

        jLabel11.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel11.setText("Cidade:");

        jLabel12.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel12.setText("Bairro:");

        jLabel13.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel13.setText("Cartão Nacional do Sus:");

        jLabel14.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel14.setText("Sexo:");

        sexocbx.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        sexocbx.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione...", "M", "F" }));

        enderecotxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                enderecotxtActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel15.setText("Nº:");

        jLabel3.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 153, 102));
        jLabel3.setText("Gerenciar dados pessoais do Vacinador");

        jLabel4.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel4.setText("Nome Completo:");

        jLabel16.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel16.setText("CEP:");

        jLabel5.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel5.setText("E-mail:");

        jLabel6.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel6.setText("Senha:");

        jLabel7.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel7.setText("Confirme sua Senha:");

        jLabel8.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel8.setText("Data de Nascimento");

        jLabel17.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel17.setText("UF:");
        jLabel17.setToolTipText("");

        jLabel9.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel9.setText("Telefone de Contato:");

        jLabel18.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel18.setText("CPF:");

        jLabel20.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel20.setText("CBO (Classificação Brasileira de Ocupações):");

        jPanel6.setBackground(new java.awt.Color(153, 255, 153));
        jPanel6.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        cadastrarVacinador.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        cadastrarVacinador.setText("Atualizar");
        cadastrarVacinador.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        cadastrarVacinador.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cadastrarVacinadorMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                cadastrarVacinadorMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                cadastrarVacinadorMouseExited(evt);
            }
        });
        cadastrarVacinador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadastrarVacinadorActionPerformed(evt);
            }
        });

        DeletarVacinador.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        DeletarVacinador.setText("Deletar");
        DeletarVacinador.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        DeletarVacinador.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DeletarVacinadorMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                DeletarVacinadorMouseEntered(evt);
            }
        });
        DeletarVacinador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeletarVacinadorActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel2.setText("CPF do Vacinador");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(cadastrarVacinador, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(DeletarVacinador, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(cpfVacinadortxt, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 49, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cpfVacinadortxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cadastrarVacinador, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(DeletarVacinador, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        painelmenu.setBackground(new java.awt.Color(0, 153, 204));
        painelmenu.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        painelmenu.setRequestFocusEnabled(false);

        Cadastrese.setBackground(new java.awt.Color(0, 153, 153));
        Cadastrese.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        Cadastrese.setForeground(new java.awt.Color(255, 255, 255));
        Cadastrese.setText("Cadastre");
        Cadastrese.setBorder(null);
        Cadastrese.setContentAreaFilled(false);
        Cadastrese.setDefaultCapable(false);
        Cadastrese.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                CadastreseMouseEntered(evt);
            }
        });
        Cadastrese.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CadastreseActionPerformed(evt);
            }
        });

        FaleConosco.setBackground(new java.awt.Color(0, 153, 153));
        FaleConosco.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        FaleConosco.setForeground(new java.awt.Color(255, 255, 255));
        FaleConosco.setText("Fale Conosco");
        FaleConosco.setContentAreaFilled(false);
        FaleConosco.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                FaleConoscoMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                FaleConoscoMouseEntered(evt);
            }
        });
        FaleConosco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FaleConoscoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout painelmenuLayout = new javax.swing.GroupLayout(painelmenu);
        painelmenu.setLayout(painelmenuLayout);
        painelmenuLayout.setHorizontalGroup(
            painelmenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelmenuLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Cadastrese, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(FaleConosco)
                .addContainerGap())
        );
        painelmenuLayout.setVerticalGroup(
            painelmenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, painelmenuLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(painelmenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Cadastrese)
                    .addComponent(FaleConosco)))
        );

        jButton1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jButton1.setText("Tabela de Vacinadores Cadastrados");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(painelmenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(50, 50, 50)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addComponent(jLabel7)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(confsenhapass))
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addComponent(jLabel8)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(datanasctxt))
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addComponent(jLabel9)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(teltxt))
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel4)
                                            .addComponent(jLabel5)
                                            .addComponent(jLabel6))
                                        .addGap(31, 31, 31)
                                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(emailtxt, javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(nometxt)
                                            .addComponent(senhapass)))
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel10)
                                            .addComponent(jLabel18)
                                            .addComponent(jLabel11))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(cidadetxt, javax.swing.GroupLayout.DEFAULT_SIZE, 186, Short.MAX_VALUE)
                                            .addComponent(bairrotxt)
                                            .addComponent(enderecotxt, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(cpftxt, javax.swing.GroupLayout.Alignment.LEADING))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel4Layout.createSequentialGroup()
                                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel14)
                                                    .addComponent(jLabel15))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                    .addComponent(numtxt, javax.swing.GroupLayout.DEFAULT_SIZE, 91, Short.MAX_VALUE)
                                                    .addComponent(sexocbx, 0, 1, Short.MAX_VALUE)))
                                            .addGroup(jPanel4Layout.createSequentialGroup()
                                                .addComponent(jLabel17)
                                                .addGap(18, 18, 18)
                                                .addComponent(uftxt)
                                                .addGap(44, 44, 44))))
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel4Layout.createSequentialGroup()
                                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel12)
                                                    .addComponent(jLabel13))
                                                .addGap(113, 113, 113)
                                                .addComponent(jLabel16)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(ceptxt, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(jLabel3))
                                        .addGap(0, 0, Short.MAX_VALUE)))
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addGap(107, 107, 107)
                                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addGap(172, 172, 172)
                                        .addComponent(jButton1)))
                                .addGap(0, 320, Short.MAX_VALUE))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(cnstxt, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addComponent(jLabel20)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cbotxt, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE))))))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(painelmenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 25, Short.MAX_VALUE)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(nometxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(emailtxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(senhapass, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(confsenhapass, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(datanasctxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(teltxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel18)
                            .addComponent(cpftxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel14)
                            .addComponent(sexocbx, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(enderecotxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel15)
                            .addComponent(numtxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(bairrotxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel16)
                            .addComponent(ceptxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel12))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(cidadetxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel17)
                                .addComponent(uftxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(cnstxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel20)
                            .addComponent(cbotxt, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(117, 117, 117))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton1)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cadastrarVacinadorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cadastrarVacinadorMouseClicked

    }//GEN-LAST:event_cadastrarVacinadorMouseClicked

    private void cadastrarVacinadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadastrarVacinadorActionPerformed

        try {

            Connection conexao = null;
            PreparedStatement statement = null;

            String url = "jdbc:mysql://localhost:3355/db_vacinamais";
            String usuario = "root";
            String senha = "usbw";

            conexao = DriverManager.getConnection(url, usuario, senha);

            String sql = "update vacinador  set nome_vacinador = ?,email_vacinador = ?,senha_vacinador = ?,nascimento_vacinador = ?,tel_vacinador = ?,\n" +
            "cpf_vacinador = ?,sexo_vacinador = ?,endereco_vacinador = ?,numero_casa_vacinador = ?,bairro_vacinador = ?,cep_vacinador = ?,cidade_vacinador = ?,"
            + "uf_vacinador = ?,cns_vacinador = ?,cbo_vacinador = ? where cpf_vacinador = ?";

            statement = conexao.prepareStatement(sql);

            statement.setString(1, nometxt.getText());
            statement.setString(2, emailtxt.getText());
            statement.setString(3, senhapass.getText());
            statement.setString(4, datanasctxt.getText());
            statement.setString(5, teltxt.getText());
            statement.setString(6, cpftxt.getText());
            statement.setString(7, sexocbx.getSelectedItem().toString());
            statement.setString(8, enderecotxt.getText());
            statement.setString(9, numtxt.getText());
            statement.setString(10, bairrotxt.getText());
            statement.setString(11, ceptxt.getText());
            statement.setString(12, cidadetxt.getText());
            statement.setString(13, uftxt.getText());
            statement.setString(14, cnstxt.getText());
            statement.setString(15, cbotxt.getText());
            statement.setString(16, cpfVacinadortxt.getText());
            
            
            int linhasAfetadas = statement.executeUpdate();
            

            if(linhasAfetadas > 0 ){
                
                JOptionPane.showMessageDialog(null, "Vacinador Atualizado");
                
            }else {
                JOptionPane.showMessageDialog(null, "Erro ao Atualizar");
            }

            statement.close();
            conexao.close();

        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null, "Erro ao Atualizar" + ex);

        }

    }//GEN-LAST:event_cadastrarVacinadorActionPerformed

    private void enderecotxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_enderecotxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_enderecotxtActionPerformed

    private void DeletarVacinadorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DeletarVacinadorMouseClicked
Connection conexao = null;
        PreparedStatement statement = null;
        
        String url = "jdbc:mysql://localhost:3355/db_vacinamais";
        String usuario = "root";
        String senha = "usbw";
        
        try {
            conexao = DriverManager.getConnection(url, usuario, senha);
            String sql = "delete from vacinador where id_vacinador = ?";
            
            statement = conexao.prepareStatement(sql);
            statement.setString(1, cpfVacinadortxt.getText());
            
            int linhasAfetadas = statement.executeUpdate();
            
            if(linhasAfetadas > 0){
                
                JOptionPane.showMessageDialog(rootPane,"Dados excluidos com sucesso");
               
            }else {
                JOptionPane.showMessageDialog(rootPane,"Erro ao deletar dados");
            }
            
            // TODO add your handling code here:
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane,"Erro ao inserir dados: " + ex.getMessage());
        } finally {
            try{
                if(statement != null){
                    statement.close();
                }  
                if(statement != null){
                    conexao.close();
                }
            }   catch (SQLException ex) {
                JOptionPane.showMessageDialog(rootPane,"Erro ao fechar conexão " + ex.getMessage());
            }
        }       
    }//GEN-LAST:event_DeletarVacinadorMouseClicked

    private void DeletarVacinadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeletarVacinadorActionPerformed
        
    }//GEN-LAST:event_DeletarVacinadorActionPerformed

    private void jPanel4ComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_jPanel4ComponentResized

    }//GEN-LAST:event_jPanel4ComponentResized

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
       
        TelaCadastroProfissional cad = new TelaCadastroProfissional();
       cad.setVisible(true);
       dispose();
       
       
    }//GEN-LAST:event_jButton6ActionPerformed

    private void CadastreseMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CadastreseMouseEntered
        Cadastrese.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_CadastreseMouseEntered

    private void CadastreseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CadastreseActionPerformed

        TelaEscolhaCadastro escolhe = new TelaEscolhaCadastro();
        escolhe.setVisible(true);
        dispose();

    }//GEN-LAST:event_CadastreseActionPerformed

    private void FaleConoscoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FaleConoscoMouseClicked

    }//GEN-LAST:event_FaleConoscoMouseClicked

    private void FaleConoscoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FaleConoscoMouseEntered
        FaleConosco.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_FaleConoscoMouseEntered

    private void FaleConoscoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FaleConoscoActionPerformed
        TelaAjudaBotao ajuda = new TelaAjudaBotao();
        ajuda.setVisible(true);
 
    }//GEN-LAST:event_FaleConoscoActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       
        VacinadoresCadastrados vaci = new VacinadoresCadastrados();
        vaci.setVisible(true);
        dispose();    
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void cadastrarVacinadorMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cadastrarVacinadorMouseEntered
        
        cadastrarVacinador.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        Color cor = new Color(0,204,255);

        cadastrarVacinador.setBackground(cor);
        
        
        
    }//GEN-LAST:event_cadastrarVacinadorMouseEntered

    private void cadastrarVacinadorMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cadastrarVacinadorMouseExited
        
        Color cor = new Color(255,255,255);

        cadastrarVacinador.setBackground(cor);
        
    }//GEN-LAST:event_cadastrarVacinadorMouseExited

    private void DeletarVacinadorMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DeletarVacinadorMouseEntered
       
        DeletarVacinador.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        Color cor = new Color(255,51,51);

        DeletarVacinador.setBackground(cor);
        
    }//GEN-LAST:event_DeletarVacinadorMouseEntered

    private void vacinamais1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_vacinamais1MouseClicked
        ATelaInicialVacinamais tela = new ATelaInicialVacinamais();
        tela.setVisible(true);
        dispose();
    }//GEN-LAST:event_vacinamais1MouseClicked

    private void vacinamais1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_vacinamais1MouseEntered

        vacinamais1.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_vacinamais1MouseEntered

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaEditarProfissional.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaEditarProfissional.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaEditarProfissional.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaEditarProfissional.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaEditarProfissional().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Cadastrese;
    private javax.swing.JButton DeletarVacinador;
    private javax.swing.JButton FaleConosco;
    private javax.swing.JTextField bairrotxt;
    private javax.swing.JButton cadastrarVacinador;
    private javax.swing.JTextField cbotxt;
    private javax.swing.JTextField ceptxt;
    private javax.swing.JTextField cidadetxt;
    private javax.swing.JTextField cnstxt;
    private javax.swing.JPasswordField confsenhapass;
    private javax.swing.JTextField cpfVacinadortxt;
    private javax.swing.JTextField cpftxt;
    private javax.swing.JTextField datanasctxt;
    private javax.swing.JTextField emailtxt;
    private javax.swing.JTextField enderecotxt;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JTextField nometxt;
    private javax.swing.JTextField numtxt;
    private javax.swing.JPanel painelmenu;
    private javax.swing.JPasswordField senhapass;
    private javax.swing.JComboBox<String> sexocbx;
    private javax.swing.JTextField teltxt;
    private javax.swing.JTextField uftxt;
    private javax.swing.JLabel vacinamais1;
    // End of variables declaration//GEN-END:variables

    /**
     * @return the bairrotxt
     */
    public String getBairrotxt() {
        return bairrotxt.getText();
    }

    /**
     * @param bairrotxt the bairrotxt to set
     */
    public void setBairrotxt(String bairrotxt) {
        this.bairrotxt.setText(bairrotxt);
    }

    /**
     * @return the cbotxt
     */
    public String getCbotxt() {
        return cbotxt.getText();
    }

    /**
     * @param cbotxt the cbotxt to set
     */
    public void setCbotxt(String cbotxt) {
        this.cbotxt.setText(cbotxt);
    }

    /**
     * @return the ceptxt
     */
    public String getCeptxt() {
        return ceptxt.getText();
    }

    /**
     * @param ceptxt the ceptxt to set
     */
    public void setCeptxt(String ceptxt) {
        this.ceptxt.setText(ceptxt);
    }

    /**
     * @return the cidadetxt
     */
    public String getCidadetxt() {
        return cidadetxt.getText();
    }

    /**
     * @param cidadetxt the cidadetxt to set
     */
    public void setCidadetxt(String cidadetxt) {
        this.cidadetxt.setText(cidadetxt);
    }

    /**
     * @return the cnstxt
     */
    public String getCnstxt() {
        return cnstxt.getText();
    }

    /**
     * @param cnstxt the cnstxt to set
     */
    public void setCnstxt(String cnstxt) {
        this.cnstxt.setText(cnstxt);
    }

    /**
     * @return the cpfVacinadortxt
     */
    public String getCpfVacinadortxt() {
        return cpfVacinadortxt.getText();
    }

    /**
     * @param cpfVacinadortxt the cpfVacinadortxt to set
     */
    public void setCpfVacinadortxt(String cpfVacinadortxt) {
        this.cpfVacinadortxt.setText(cpfVacinadortxt);
    }

    /**
     * @return the cpftxt
     */
    public String getCpftxt() {
        return cpftxt.getText();
    }

    /**
     * @param cpftxt the cpftxt to set
     */
    public void setCpftxt(String cpftxt) {
        this.cpftxt.setText(cpftxt);
    }

    /**
     * @return the datanasctxt
     */
    public String getDatanasctxt() {
        return datanasctxt.getText();
    }

    /**
     * @param datanasctxt the datanasctxt to set
     */
    public void setDatanasctxt(String datanasctxt) {
        this.datanasctxt.setText(datanasctxt);
    }

    /**
     * @return the emailtxt
     */
    public String getEmailtxt() {
        return emailtxt.getText();
    }

    /**
     * @param emailtxt the emailtxt to set
     */
    public void setEmailtxt(String emailtxt) {
        this.emailtxt.setText(emailtxt);
    }

    /**
     * @return the enderecotxt
     */
    public String getEnderecotxt() {
        return enderecotxt.getText();
    }

    /**
     * @param enderecotxt the enderecotxt to set
     */
    public void setEnderecotxt(String enderecotxt) {
        this.enderecotxt.setText(enderecotxt);
    }

    /**
     * @return the nometxt
     */
    public String getNometxt() {
        return nometxt.getText();
    }

    /**
     * @param nometxt the nometxt to set
     */
    public void setNometxt(String nometxt) {
        this.nometxt.setText(nometxt);
    }

    /**
     * @return the numtxt
     */
    public String getNumtxt() {
        return numtxt.getText();
    }

    /**
     * @param numtxt the numtxt to set
     */
    public void setNumtxt(String numtxt) {
        this.numtxt.setText(numtxt);
    }

    /**
     * @return the senhapass
     */
    public String getSenhapass() {
        return senhapass.getText();
    }

    /**
     * @param senhapass the senhapass to set
     */
    public void setSenhapass(String senhapass) {
        this.senhapass.setText(senhapass);
    }

    /**
     * @return the sexocbx
     */
    public String getSexocbx() {
        return sexocbx.getSelectedItem().toString();
    }

    /**
     * @param sexocbx the sexocbx to set
     */
    public void setSexocbx(String sexocbx) {
        this.sexocbx.setSelectedItem(sexocbx);
    }

    /**
     * @return the teltxt
     */
    public String getTeltxt() {
        return teltxt.getText();
    }

    /**
     * @param teltxt the teltxt to set
     */
    public void setTeltxt(String teltxt) {
        this.teltxt.setText(teltxt);
    }

    /**
     * @return the uftxt
     */
    public String getUftxt() {
        return uftxt.getText();
    }

    /**
     * @param uftxt the uftxt to set
     */
    public void setUftxt(String uftxt) {
        this.uftxt.setText(uftxt);
    }

}
