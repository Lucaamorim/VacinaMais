
package TelasImplementadas;


import java.awt.Cursor;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class TelaCartaodeVacina extends javax.swing.JFrame {

    
    public TelaCartaodeVacina() {
        initComponents();
        setExtendedState(TelaCartaodeVacina.MAXIMIZED_BOTH);
    }
    
    public void exportarTXT(String sql) throws IOException{
    
        try {
            
            Connection conexao = null;
            PreparedStatement statement = null;
            
            String url = "jdbc:mysql://localhost:3355/db_vacinamais";
            String usuario = "root";               
            String senha = "usbw";
            
            conexao = DriverManager.getConnection(url,usuario,senha);
             
            statement = conexao.prepareStatement (sql);
           
            ResultSet resultado = statement.executeQuery(sql);
            
            FileWriter arq = new FileWriter("C:\\Users\\lucas\\OneDrive\\Área de Trabalho\\CartaoN."+ Math.random()+".txt"); 
            
            PrintWriter gravarArq = new PrintWriter(arq);
            
                gravarArq.printf("-------------------------------------------------------- Cartao de Vacina ----------------------------------------------------" + "\n");
                while(resultado.next()){
                
                gravarArq.printf(" CPF do Paciente :" + resultado.getString("cpf_paciente")+ " | ");
                gravarArq.printf(" Nome da Vacina :" + resultado.getString("nome_vacina")+ " | ");                
                gravarArq.printf(" Dose :" + resultado.getString("dose")+ " | ");
                gravarArq.printf(" Data que recebeu a dose :" + resultado.getString("data_agendamento")+ " | ");
                gravarArq.printf(" Local :" + resultado.getString("nome_fantasia_estabelecimento")+ " | \n");
                gravarArq.printf("--------------------------------------------------------------------------------------------------------------------------------" + "\n");
            }

            if (resultado.isAfterLast()== true){
                JOptionPane.showMessageDialog(rootPane, "Certinho! Verifique sua Area de Trabalho"); 
                arq.close();
               
            } else if(resultado.isBeforeFirst() == false){
                JOptionPane.showMessageDialog(rootPane, "Algo deu Errado");
                        }
 
        } catch (SQLException | IOException ex) {
            JOptionPane.showMessageDialog(rootPane, "Verifique sua conexão com o Banco : " + ex);
        }


  };
    
    
    
    private void MetodoTable(String sql) {
    
        try {
            Connection con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3355/db_vacinamais", "root", "usbw");
            PreparedStatement banco = (PreparedStatement)con.prepareStatement(sql);
            banco.execute(); 
            
            ResultSet resultado = banco.executeQuery(sql);
            
            DefaultTableModel model =(DefaultTableModel) TableCadastros.getModel();
            model.setNumRows(0);
            
            while(resultado.next())
            {
                model.addRow(new Object[]
                {
                    resultado.getString("id_agendamento"),
                    resultado.getString("cpf_paciente"),
                    resultado.getString("nome_vacina"),
                    resultado.getString("dose"),                    
                    resultado.getString("data_agendamento"),
                    resultado.getString("nome_fantasia_estabelecimento"),
   
                });
            }
            
            if(model.getRowCount() == 0){
            JOptionPane.showMessageDialog(rootPane, "Nenhum CPF encontrado");
            
            }            
            
            banco.close();
            con.close();
            
        } catch (SQLException ex) {
            
            JOptionPane.showMessageDialog(rootPane, "Erro ao inserir" + ex);
            
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        vacinamais = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        pesqCPF = new javax.swing.JTextField();
        jButton8 = new javax.swing.JButton();
        painelmenu = new javax.swing.JPanel();
        agendese = new javax.swing.JButton();
        Consulte = new javax.swing.JButton();
        FaleConosco = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        TableCadastros = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 153, 204));

        jPanel2.setBackground(new java.awt.Color(0, 204, 255));
        jPanel2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, new java.awt.Color(0, 204, 204), null, null));

        vacinamais.setFont(new java.awt.Font("Bauhaus 93", 0, 85)); // NOI18N
        vacinamais.setForeground(new java.awt.Color(255, 255, 255));
        vacinamais.setText("Vacina +");
        vacinamais.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                vacinamaisMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                vacinamaisMouseEntered(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(403, 403, 403)
                        .addComponent(jLabel5))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(vacinamais)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
                .addComponent(vacinamais, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 153, 102));
        jLabel2.setText("Tire seu Cartão de Vacina");

        jLabel3.setFont(new java.awt.Font("Dialog", 1, 20)); // NOI18N
        jLabel3.setText("Digite seu CPF:");

        pesqCPF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jButton8.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jButton8.setText("Vizualizar na janela");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        painelmenu.setBackground(new java.awt.Color(0, 153, 204));
        painelmenu.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        painelmenu.setRequestFocusEnabled(false);

        agendese.setBackground(new java.awt.Color(0, 153, 153));
        agendese.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        agendese.setForeground(new java.awt.Color(255, 255, 255));
        agendese.setText("Agendar");
        agendese.setBorderPainted(false);
        agendese.setContentAreaFilled(false);
        agendese.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        agendese.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                agendeseMouseEntered(evt);
            }
        });
        agendese.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agendeseActionPerformed(evt);
            }
        });

        Consulte.setBackground(new java.awt.Color(0, 153, 153));
        Consulte.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        Consulte.setForeground(new java.awt.Color(255, 255, 255));
        Consulte.setText("Consulte seu Agendamento");
        Consulte.setContentAreaFilled(false);
        Consulte.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ConsulteMouseEntered(evt);
            }
        });
        Consulte.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConsulteActionPerformed(evt);
            }
        });

        FaleConosco.setBackground(new java.awt.Color(0, 153, 153));
        FaleConosco.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        FaleConosco.setForeground(new java.awt.Color(255, 255, 255));
        FaleConosco.setText("Fale Conosco");
        FaleConosco.setContentAreaFilled(false);
        FaleConosco.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                FaleConoscoMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                FaleConoscoMouseEntered(evt);
            }
        });
        FaleConosco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FaleConoscoActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(0, 153, 204));
        jButton2.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Serviços para Vacinadores");
        jButton2.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jButton2.setBorderPainted(false);
        jButton2.setContentAreaFilled(false);
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton2MouseEntered(evt);
            }
        });
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout painelmenuLayout = new javax.swing.GroupLayout(painelmenu);
        painelmenu.setLayout(painelmenuLayout);
        painelmenuLayout.setHorizontalGroup(
            painelmenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelmenuLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(agendese)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Consulte)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(FaleConosco))
        );
        painelmenuLayout.setVerticalGroup(
            painelmenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, painelmenuLayout.createSequentialGroup()
                .addGap(0, 2, Short.MAX_VALUE)
                .addGroup(painelmenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(agendese)
                    .addComponent(Consulte)
                    .addComponent(FaleConosco)
                    .addComponent(jButton2)))
        );

        TableCadastros.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "iD", "CPF", "Vacina ", "Dose Tomada", "Data em que Ocorreu", "Estabelecimento"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TableCadastros.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TableCadastrosMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(TableCadastros);

        jButton1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jButton1.setText("Baixar TXT para a minha Área de Trabalho");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(painelmenu, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(230, 230, 230)
                .addComponent(jButton8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(90, 90, 90))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel2))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(523, 523, 523)
                        .addComponent(jLabel3)
                        .addGap(59, 59, 59)
                        .addComponent(pesqCPF, javax.swing.GroupLayout.PREFERRED_SIZE, 261, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 10, Short.MAX_VALUE)))
                .addGap(495, 495, 495))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(painelmenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(79, 79, 79)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 91, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(pesqCPF, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15)))
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton8, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton1, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void agendeseMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_agendeseMouseEntered
        agendese.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_agendeseMouseEntered

    private void ConsulteMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ConsulteMouseEntered
        Consulte.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_ConsulteMouseEntered

    private void ConsulteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConsulteActionPerformed
        TelaConsultaAgendamento agendar = new TelaConsultaAgendamento();
        agendar.setVisible(true);
        dispose();
    }//GEN-LAST:event_ConsulteActionPerformed

    private void FaleConoscoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FaleConoscoMouseClicked

    }//GEN-LAST:event_FaleConoscoMouseClicked

    private void FaleConoscoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FaleConoscoMouseEntered
        FaleConosco.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_FaleConoscoMouseEntered

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        
        this.MetodoTable("select * from agendamento where cpf_paciente = " + pesqCPF.getText());
        
        
    }//GEN-LAST:event_jButton8ActionPerformed

    private void TableCadastrosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TableCadastrosMouseClicked

        int linha = TableCadastros.getSelectedRow();
        pesqCPF.setText(TableCadastros.getValueAt(linha,1).toString());

    }//GEN-LAST:event_TableCadastrosMouseClicked

    private void FaleConoscoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FaleConoscoActionPerformed
        TelaAjudaBotao ajuda = new TelaAjudaBotao();

        ajuda.setVisible(true);
    }//GEN-LAST:event_FaleConoscoActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       
        try {
            exportarTXT("select * from agendamento where cpf_paciente = " + this.pesqCPF.getText());
        } catch (IOException ex) {
            Logger.getLogger(TelaCartaodeVacina.class.getName()).log(Level.SEVERE, null, ex);
        }       
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseEntered

        jButton2.setCursor(new Cursor(Cursor.HAND_CURSOR));

    }//GEN-LAST:event_jButton2MouseEntered

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        

        String input = JOptionPane.showInputDialog( "Codigo do Vacinador",JOptionPane.OK_CANCEL_OPTION);

        try {

            Connection conexao = null;
            PreparedStatement statement = null;

            String url = "jdbc:mysql://localhost:3355/db_vacinamais";
            String usuario = "root";
            String senha = "usbw";

            conexao = DriverManager.getConnection(url, usuario, senha);

            String sql = "select * from vacinador where cpf_vacinador = ?";

            statement = conexao.prepareStatement(sql);

            statement.setString(1, input);

            ResultSet resultado = statement.executeQuery();

            while(resultado.next()){

                resultado.findColumn("cpf_vacinador");

            }

            if (resultado.isAfterLast() == true) {

                TelaEscolhaCadastro tel = new  TelaEscolhaCadastro();
                tel.setVisible(true);
                dispose();
            } else if (resultado.isBeforeFirst() == false){

                JOptionPane.showMessageDialog(rootPane,"Acesso Negado!","Proibido",JOptionPane.ERROR_MESSAGE);

            }
        } catch (SQLException ex) {
            
             JOptionPane.showMessageDialog(rootPane,"Erro MySql: " + ex,"Fale Conosco",JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_jButton2ActionPerformed

    private void agendeseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agendeseActionPerformed
        TelaAgendar ag = new TelaAgendar();
        ag.setVisible(true);
        dispose();
    }//GEN-LAST:event_agendeseActionPerformed

    private void vacinamaisMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_vacinamaisMouseClicked
        ATelaInicialVacinamais tela = new ATelaInicialVacinamais();
        tela.setVisible(true);
        dispose();
    }//GEN-LAST:event_vacinamaisMouseClicked

    private void vacinamaisMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_vacinamaisMouseEntered

        vacinamais.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_vacinamaisMouseEntered

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaCartaodeVacina.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaCartaodeVacina.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaCartaodeVacina.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaCartaodeVacina.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaCartaodeVacina().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Consulte;
    private javax.swing.JButton FaleConosco;
    private javax.swing.JTable TableCadastros;
    private javax.swing.JButton agendese;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton8;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPanel painelmenu;
    private javax.swing.JTextField pesqCPF;
    private javax.swing.JLabel vacinamais;
    // End of variables declaration//GEN-END:variables
}
